# Trees Dataset > 2025-06-23 2:02am
https://universe.roboflow.com/anthonyhmr/trees-dataset-hogb8

Provided by a Roboflow user
License: CC BY 4.0

